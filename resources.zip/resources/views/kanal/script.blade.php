<script>
  $(document).ready(function() {
    $('a.kanal-button, .kanal-nav').hover(function() {
      $('.kanal-nav').fadeIn(100);
    }, function() {
      $('.kanal-nav').fadeOut(100);
    });
  });
</script>