dari : {{ $mail['name'] }} ({{ $mail['email'] }})  <br/>
subjek : {{ $mail['subject'] }} <br/>
pesan : {{ $mail['message'] }}
